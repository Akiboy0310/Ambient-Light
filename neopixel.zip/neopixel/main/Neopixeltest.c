#include "led_strip.h"
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include <stdlib.h>

#define length_of_led_strip 39 
// When we setup the NeoPixel library, we tell it how many pixels, and which pin to use to send signals.
// Note that for older NeoPixel strips you might need to change the third parameter--see the strandtest
/** @brief Double buffering for neopixels - buffer 1 */
struct led_color_t *neop_buf1 = NULL;
/** @brief Double buffering for neopixels - buffer 2 */
struct led_color_t *neop_buf2 = NULL;
struct led_strip_t led_strip = {
      .rgb_led_type = RGB_LED_TYPE_WS2812,
      .rmt_channel = RMT_CHANNEL_7,
      .gpio = 32,
      .led_strip_length = length_of_led_strip,
  };
uint8_t led_init(void){
    neop_buf1 = malloc(sizeof(struct led_color_t)*length_of_led_strip);
    neop_buf2 = malloc(sizeof(struct led_color_t)*length_of_led_strip);
  if(neop_buf1 == NULL || neop_buf2 == NULL)
  {
    printf("Not enough memory to initialize Neopixel buffer");
    return ESP_FAIL;
  }
  
  //init remaining stuff of led strip driver struct
  led_strip.access_semaphore = xSemaphoreCreateBinary();
  led_strip.led_strip_buf_1 = neop_buf1;
  led_strip.led_strip_buf_2 = neop_buf2;
  //initialize module
  
  if(led_strip_init(&led_strip) == false)
  {
    printf("Error initializing led strip (Neopixels)!");
    return ESP_FAIL;
  }
    return 0; 
}

void app_main(void){ 
    /*++++ init Neopixel driver ++++*/
    led_init();
    while(1){
        led_strip_set_pixel_rgb(&led_strip,length_of_led_strip, 255, 0,0);
        vTaskDelay(1000/portTICK_PERIOD_MS); //delay 1000ms
    }
}
